﻿using Microsoft.AspNetCore.Mvc;
using CalculatorMVC.Models;

namespace CalculatorMVC.Controllers
{
    public class CalculatorController : Controller
    {
        private static double? _previousResult = null;

        [HttpGet]
        public IActionResult Index()
        {
            _previousResult = null;
            return View(new CalculatorModel());
        }

        [HttpPost]
        public IActionResult Index(CalculatorModel model, string button)
        {
            // Пункт 5: Проверка по значению атрибута value
            if (button == "clear")
            {
                model.Operand1 = 0;
                model.Operand2 = 0;
                model.Operation = null;
                model.Result = 0;
                _previousResult = null;
                ViewBag.Message = "Поля очищены";
                return View(model);
            }

            if (ModelState.IsValid)
            {
                double? oldResult = _previousResult;

                switch (model.Operation)
                {
                    case "+":
                        model.Result = (double)model.Operand1 + model.Operand2;
                        break;
                    case "-":
                        model.Result = (double)model.Operand1 - model.Operand2;
                        break;
                    case "*":
                        model.Result = (double)model.Operand1 * model.Operand2;
                        break;
                    case "/":
                        if (model.Operand2 != 0)
                            model.Result = (double)model.Operand1 / model.Operand2;
                        else
                            ModelState.AddModelError("", "Деление на ноль!");
                        break;
                }

                // Пункт 2: Проверка равенства с предыдущим результатом через ViewBag
                if (ModelState.IsValid)
                {
                    if (oldResult.HasValue)
                    {
                        if (model.Result == oldResult.Value)
                        {
                            ViewBag.Message = $"Результат {model.Result} совпадает с предыдущим результатом {oldResult.Value}";
                        }
                        else
                        {
                            ViewBag.Message = $"Результат изменился: {oldResult.Value} → {model.Result}";
                        }
                    }
                    else
                    {
                        ViewBag.Message = $"Результат вычисления: {model.Result}";
                    }

                    _previousResult = model.Result;
                }
            }

            return View(model);
        }
    }
}