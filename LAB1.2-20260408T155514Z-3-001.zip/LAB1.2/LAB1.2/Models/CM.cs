﻿using System.ComponentModel.DataAnnotations;

namespace CalculatorMVC.Models
{
    public class CalculatorModel
    {
        public ushort Operand1 { get; set; }

        public double Operand2 { get; set; }

        public string Operation { get; set; }

        public double Result { get; set; }
    }
}