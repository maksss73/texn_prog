using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LAB1._2.Views.Calculator
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
