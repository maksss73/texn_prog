﻿using Microsoft.AspNetCore.Mvc;
using CalculatorMVC.Models;
using System;

namespace CalculatorMVC.Controllers
{
    public class CalculatorController : Controller
    {
        private static double? _previousResult = null;

        [HttpGet]
        public IActionResult Index()
        {
            _previousResult = null;
            return View(new CalculatorModel());
        }

        [HttpPost]
        public IActionResult Index(CalculatorModel model, string button)
        {
            if (button == "clear")
            {
                model.Operand1 = 0;
                model.Operand2 = null;
                model.Operation = null;
                model.Result = 0;
                _previousResult = null;
                ViewBag.Message = "Поля очищены";
                return View(model);
            }

            // Преобразуем string в double для вычислений
            double operand2Value = 0;
            if (!string.IsNullOrEmpty(model.Operand2))
            {
                double.TryParse(model.Operand2.Replace('.', ','), out operand2Value);
            }

            if (ModelState.IsValid)
            {
                double? oldResult = _previousResult;

                switch (model.Operation)
                {
                    case "+":
                        model.Result = (double)model.Operand1 + operand2Value;
                        break;
                    case "-":
                        model.Result = (double)model.Operand1 - operand2Value;
                        break;
                    case "*":
                        model.Result = (double)model.Operand1 * operand2Value;
                        break;
                    case "/":
                        if (operand2Value != 0)
                            model.Result = (double)model.Operand1 / operand2Value;
                        else
                            ModelState.AddModelError("", "Деление на ноль!");
                        break;
                }

                if (ModelState.IsValid)
                {
                    if (oldResult.HasValue)
                    {
                        if (model.Result == oldResult.Value)
                            ViewBag.Message = $"Результат {model.Result} совпадает с предыдущим";
                        else
                            ViewBag.Message = $"Результат изменился: {oldResult.Value} → {model.Result}";
                    }
                    else
                    {
                        ViewBag.Message = $"Результат: {model.Result}";
                    }
                    _previousResult = model.Result;
                }
            }

            return View(model);
        }
    }
}