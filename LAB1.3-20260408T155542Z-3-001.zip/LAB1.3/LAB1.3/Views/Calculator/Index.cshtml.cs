using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LAB1._3.Views.Calculator
{
    public class IndesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
