﻿using System.ComponentModel.DataAnnotations;

namespace CalculatorMVC.Models
{
    public class CalculatorModel
    {
        [Required(ErrorMessage = "Поле 'Первое число' обязательно для заполнения")]
        public ushort Operand1 { get; set; }

        [StringLength(10, MinimumLength = 1, ErrorMessage = "Длина числа должна быть от 1 до 10 символов")]
        public string Operand2 { get; set; }

        public string Operation { get; set; }

        public double Result { get; set; }
    }
}