using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LAB1._4.Views.Calculator
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
