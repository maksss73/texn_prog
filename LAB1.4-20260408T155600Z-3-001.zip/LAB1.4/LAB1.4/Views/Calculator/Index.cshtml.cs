using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LAB1._4.Views.Calculator
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
