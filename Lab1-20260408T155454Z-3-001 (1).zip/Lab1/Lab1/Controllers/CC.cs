﻿using Microsoft.AspNetCore.Mvc;
using CalculatorMVC.Models;

namespace CalculatorMVC.Controllers
{
    public class CalculatorController : Controller // Обязательно Microsoft.AspNetCore.Mvc.Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new CalculatorModel());
        }

        [HttpPost]
        public IActionResult Index(CalculatorModel model)
        {
            if (ModelState.IsValid)
            {
                switch (model.Operation)
                {
                    case "+":
                        model.Result = model.Operand1 + model.Operand2;
                        break;
                    case "-":
                        model.Result = model.Operand1 - model.Operand2;
                        break;
                    case "*":
                        model.Result = model.Operand1 * model.Operand2;
                        break;
                    case "/":
                        if (model.Operand2 != 0)
                            model.Result = model.Operand1 / model.Operand2;
                        else
                            ModelState.AddModelError("", "Деление на ноль!");
                        break;
                }
            }

            return View(model);
        }
    }
}