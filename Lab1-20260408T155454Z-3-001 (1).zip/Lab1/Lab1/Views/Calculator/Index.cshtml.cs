using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab1.Views.Calculator
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
